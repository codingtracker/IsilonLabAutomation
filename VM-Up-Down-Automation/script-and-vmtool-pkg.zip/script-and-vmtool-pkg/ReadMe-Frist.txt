In order to make the script runable with full features, please follow the steps below in your windows machine:

1. Install VMware-ovftool-3.5.0-1274719-win.x86_64.msi with default settings.

2. Install VMware-PowerCLI-6.5.0-4624819.exe with default settings.

3. Run following command at your Windows Powershell with administrator privilege.

   Install-Module -Name VMware.PowerCLI -RequiredVersion 6.5.4.7155375

